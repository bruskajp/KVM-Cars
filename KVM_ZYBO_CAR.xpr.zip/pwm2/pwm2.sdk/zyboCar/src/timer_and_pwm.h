/*
 * timer_and_pwm.h
 *
 *  Created on: Nov 20, 2017
 *      Author: ulab
 */

#ifndef SRC_TIMER_AND_PWM_H_
#define SRC_TIMER_AND_PWM_H_

#include "Xscugic.h"
#include "xttcps.h"
#include "xadcps.h"
#include "xsysmon.h"

#define TTC_DEVICE_ID_0	    XPAR_XTTCPS_0_DEVICE_ID
#define TTC_INTR_ID_0		XPAR_XTTCPS_0_INTR
#define TTC_DEVICE_ID_1	    XPAR_XTTCPS_1_DEVICE_ID
#define TTC_INTR_ID_1		XPAR_XTTCPS_1_INTR
#define INTC_DEVICE_ID		XPAR_SCUGIC_SINGLE_DEVICE_ID

static void initializeTimerSystem();
static int genTimer(int freq, XTtcPs *timer, void (*Handler)(void *));
static int genPwm(int freq, double duty_cycle, XTtcPs *timer);
static void updatePwmDutyCycle(double duty_cycle, XTtcPs *Timer);

static void SetupInterruptTimer(XScuGic *GicInstancePtr, XTtcPs *TtcPsInt, unsigned long TTC_INTR_ID, void (*Handler)(void *));
static void TimerInit(unsigned long TTC_DEVICE_ID, u32 freq, XTtcPs *Timer, unsigned long TTC_INTR_ID, void (*Handler)(void *));
static void GicSetup(XScuGic *GicInstancePtr);
static void pwmHandler(void *CallBackRef);

int used_timer_counter, used_match_counter;
//int pwm_wave_value;

static XScuGic Intc; //GIC

static void initializeTimerSystem(){
	used_timer_counter = 0;
}

static int genPwm(int freq, double duty_cycle, XTtcPs *timer){
	u16 options;
	int ret;

	ret = genTimer(freq, timer, &pwmHandler);
	if (ret < 0) { return ret; }

	XTtcPs_EnableInterrupts(timer, XTTCPS_IXR_MATCH_0_MASK);

	options =  XTtcPs_GetOptions(timer) | XTTCPS_OPTION_MATCH_MODE;
	XTtcPs_SetOptions(timer, options);

	updatePwmDutyCycle(duty_cycle, timer);

	return 0;
}

static void pwmHandler(void *CallBackRef)
{
	u32 StatusEvent;

	StatusEvent = XTtcPs_GetInterruptStatus((XTtcPs *)CallBackRef);
	XTtcPs_ClearInterruptStatus((XTtcPs *)CallBackRef, StatusEvent);

	/*if (0 != (XTTCPS_IXR_INTERVAL_MASK & StatusEvent)) {
		//printf("interval interrupt event\n\r");
		pwm_wave_value = 1;
	}

	if (0 != (XTTCPS_IXR_MATCH_0_MASK & StatusEvent)) {
		//printf("match interrupt event\n\r");
		pwm_wave_value = 0;
	}

	printf("Wave Value: %d\n\r", pwm_wave_value);*/
}

static void updatePwmDutyCycle(double duty_cycle, XTtcPs *Timer){
	u16 interval;	/* Interval value */

	interval = XTtcPs_GetInterval(Timer);
	XTtcPs_SetMatchValue(Timer, 0, (int)(interval*duty_cycle/100));
}

static int genTimer(int freq, XTtcPs *timer, void (*handler)(void *)){
	switch(used_timer_counter){
		case 0:
			TimerInit(XPAR_XTTCPS_0_DEVICE_ID, freq, timer, XPAR_XTTCPS_0_INTR, handler);
			break;
		case 1:
			TimerInit(XPAR_XTTCPS_1_DEVICE_ID, freq, timer, XPAR_XTTCPS_1_INTR, handler);
			break;
		case 2:
			TimerInit(XPAR_XTTCPS_2_DEVICE_ID, freq, timer, XPAR_XTTCPS_2_INTR, handler);
			break;
		case 3:
			//TimerInit(XPAR_XTTCPS_3_DEVICE_ID, freq, timer, XPAR_XTTCPS_3_INTR, handler);
			break;
		case 4:
			//TimerInit(XPAR_XTTCPS_4_DEVICE_ID, freq, timer, XPAR_XTTCPS_4_INTR, handler);
			break;
		case 5:
			//TimerInit(XPAR_XTTCPS_5_DEVICE_ID, freq, timer, XPAR_XTTCPS_5_INTR, handler);
			break;
		default:
			if (used_timer_counter > 5){ return -1; }
			else if (used_timer_counter < 0){ return -2; }
	}
	++used_timer_counter;
	return used_timer_counter;
}

static void TimerInit(unsigned long TTC_DEVICE_ID, u32 freq, XTtcPs *Timer, unsigned long TTC_INTR_ID, void (*Handler)(void *)){
	u16 interval;
	u8 	prescaler;
	u16 options;
	XTtcPs_Config *Config;

	XTtcPs_Stop(Timer); // This may have to go before GicSetup

 	Config = XTtcPs_LookupConfig(TTC_DEVICE_ID);

	XTtcPs_CfgInitialize(Timer, Config, Config->BaseAddress);

	options = XTTCPS_OPTION_INTERVAL_MODE | XTTCPS_OPTION_WAVE_POLARITY;

	XTtcPs_SetOptions(Timer, options);
	XTtcPs_CalcIntervalFromFreq(Timer, freq, &interval, &prescaler);

	XTtcPs_SetInterval(Timer, interval);
	XTtcPs_SetPrescaler(Timer, prescaler);

	SetupInterruptTimer(&Intc, Timer, TTC_INTR_ID, Handler);

	printf("%d\r\n",interval);
	printf("%d\r\n",prescaler);
}

static void GicSetup(XScuGic *GicInstancePtr){
	XScuGic_Config *IntcConfig; // GIC config
	Xil_ExceptionInit();

	// Init GIC
	IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);

	XScuGic_CfgInitialize(GicInstancePtr, IntcConfig,
					IntcConfig->CpuBaseAddress);

	// Connect to the hardware
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
				(Xil_ExceptionHandler)XScuGic_InterruptHandler,
				GicInstancePtr);
}

static void SetupInterruptTimer(XScuGic *GicInstancePtr, XTtcPs *TtcPsInt, unsigned long TTC_INTR_ID, void (*Handler)(void *))
{
	XScuGic_Connect(GicInstancePtr, TTC_INTR_ID,
			(Xil_ExceptionHandler)Handler, (void *)TtcPsInt);

	XScuGic_Enable(GicInstancePtr, TTC_INTR_ID);
	XTtcPs_EnableInterrupts(TtcPsInt, XTTCPS_IXR_INTERVAL_MASK);
	XTtcPs_Start(TtcPsInt);
}






#endif /* SRC_TIMER_AND_PWM_H_ */
