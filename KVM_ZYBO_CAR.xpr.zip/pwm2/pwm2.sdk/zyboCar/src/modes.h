/*
 * modes.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_MODES_H_
#define SRC_MODES_H_

#include "buttons_and_leds.h"
#include "motor_and_steering.h"
#include "lidar.h"
#include "linescan.h"

static void setMode();

static void doNothingMode();
static void basicMode();
static void accuracyMode();
static void speedMode();
static void collisionMode();
static void discoveryMode();
static void manualMode();

static void turnRightSlow();
static void turnLeftSlow();
static void turnAroundSlow();

static void turnRightFast();
static void turnLeftFast();
static void turnAroundFast();

void (*modeAction)(void);
uint8_t mode_finished = 0;

int speed = 0;
uint8_t move_dir = 0;
uint8_t marker_sigs[2] = {1, 0};

extern int intersect_seen;
uint8_t turning = 0;
uint8_t markers_opposite = 1;
//uint8_t markers_opposite = 0;
uint8_t markers_visible = 0;
int turn_count = -1;
int repetitions = -1;
extern int track_laps;
uint8_t car_ahead = 0;
uint8_t line_seen = 0;

static void setMode(){
	if (mode_count == 0){
		modeAction = doNothingMode;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0001);	//write switch data to the LEDs
	}else if (mode_count == 1){
		modeAction = basicMode;
		speed = 22;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0010);	//write switch data to the LEDs
	}else if (mode_count == 2){
		modeAction = accuracyMode;
		speed = 24;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0011);	//write switch data to the LEDs
	}else if (mode_count == 3){
		modeAction = speedMode;
		speed = 30;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0100);	//write switch data to the LEDs
	}else if (mode_count == 4){
		modeAction = collisionMode;
		speed = 28;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0101);	//write switch data to the LEDs
	}else if (mode_count == 5){
		modeAction = discoveryMode;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0110);	//write switch data to the LEDs
	}else if (mode_count == 6){
		modeAction = manualMode;
		XGpio_DiscreteWrite(&LEDInst, 1, 0b0111);	//write switch data to the LEDs
	}
}

static void turnRightSlow(){
	// TODO: change the speeds and the number of repetitions
	static int turn_actions[3][1] = {{-90}, {22}, {150}}; // [[tire angles], [speeds], [repetitions]]
		if(turn_count == -1 && repetitions == -1){
			turn_count = 0;
			repetitions = turn_actions[2][0];
		}
		if (turn_count < 1){
			steerSet(turn_actions[0][turn_count]);
			speedSet(turn_actions[1][turn_count]);
			if (repetitions <= 0){
				++turn_count;
				repetitions = turn_actions[2][turn_count];
			}else{
				--repetitions;
			}
		}else{
			turn_count = -1;
			repetitions = -1;
			turning = 0;
		}
}

static void turnLeftSlow(){
	// TODO: change the speeds and the number of repetitions
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][1] = {{90}, {22}, {100}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 1){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}else{
			--repetitions;
		}
	}else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

static void turnAroundSlow(){
	// TODO: change the speeds and the number of repetitions

	static uint8_t turn_actions[3][4] = {{0, 90, -90, 0}, {1, 1, 1, 1}, {2, 20, 20, 10}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 4){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (turn_count == 2){ move_dir = 1; }
		if (turn_count == 3){ move_dir = 0; }
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}else{
			--repetitions;
		}
	}else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

static void turnRightFast(){
	// TODO: change the speeds and the number of repetitions
	static int turn_actions[3][1] = {{-90}, {22}, {140}}; // [[tire angles], [speeds], [repetitions]]
		if(turn_count == -1 && repetitions == -1){
			turn_count = 0;
			repetitions = turn_actions[2][0];
		}
		if (turn_count < 1){
			steerSet(turn_actions[0][turn_count]);
			speedSet(turn_actions[1][turn_count]);
			if (repetitions <= 0){
				++turn_count;
				repetitions = turn_actions[2][turn_count];
			}else{
				--repetitions;
			}
		}else{
			turn_count = -1;
			repetitions = -1;
			turning = 0;
		}
}

static void turnLeftFast(){
	// TODO: change the speeds and the number of repetitions
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][1] = {{90}, {22}, {140}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 1){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}else{
			--repetitions;
		}
	}else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

static void turnAroundFast(){
	// TODO: change the speeds and the number of repetitions

	static uint8_t turn_actions[3][4] = {{0, 90, -90, 0}, {1, 1, 1, 1}, {2, 20, 20, 10}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 4){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (turn_count == 2){ move_dir = 1; }
		if (turn_count == 3){ move_dir = 0; }
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}else{
			--repetitions;
		}
	}else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

static void doNothingMode(){
	speedSet(0);
	steerSet(0);
}

static void basicMode(){
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){ turnAroundSlow(); }
			else{ turnLeftSlow(); }
		}else{
			if(marker_sigs[1]){ turnRightSlow(); }
			else{ turning = 0; }
		}
	}else{
		steerSet(steerPidOut());
		speedSet(speed);
		if(markers_opposite){
			if(intersect_seen){
				//markers_opposite = 0;
				if(!markers_visible){ turning = 1; }
			}else{
				if(speed > 28){ speed -= 1; }
			}
		}else{
			if(speed < 22){ speed +=1; };
		}
	}
}

static void accuracyMode(){
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){ turnAroundSlow(); }
			else{ turnLeftSlow(); }
		}else{
			if(marker_sigs[1]){ turnRightSlow(); }
			else{ turning = 0; }
		}
	}else{
		steerSet(steerPidOut());
		speedSet(speed);
		if(track_laps >= 2){ mode_finished = 1; modeAction = doNothingMode;}
		if(markers_opposite){
			if(intersect_seen){
				//markers_opposite = 0;
				if(!markers_visible){ turning = 1; }
			}else{
				if(speed > 30){ speed -= 1; }
			}
		}else{
			if(speed < 24){ speed +=1; };
		}
	}
}

static void speedMode(){
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){ turnAroundFast(); }
			else{ turnLeftFast(); }
		}else{
			if(marker_sigs[1]){ turnRightFast(); }
			else{ turning = 0; }
		}
	}else{
		steerSet(steerPidOut());
		speedSet(speed);
		if(track_laps >= 2){ mode_finished = 1; }
		if(markers_opposite){
			if(intersect_seen){
				//markers_opposite = 0;
				if(!markers_visible){ turning = 1; }
			}else{
				if(speed > 30){ speed -= 1; }
			}
		}else{
			if(speed < 26){ speed +=1; };
		}
	}
}

static void collisionMode(){
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){ turnAroundSlow(); }
			else{ turnLeftSlow(); }
		}else{
			if(marker_sigs[1]){ turnRightSlow(); }
			else{ turning = 0; }
		}
	}else{
		steerSet(steerPidOut());
		if(track_laps >= 2){ mode_finished = 1; }
		if(markers_opposite){
			if(intersect_seen){
				markers_opposite = 0;
				if(!markers_visible){ turning = 1; }
			}else{
				if(speed > 5){ speed -= 1; }
				// TODO: possibly put code to avoid collision here
			}
		}else{
			if(speed < 10){ speed +=1; };
			if(car_ahead){
				speedSet(colPidOut());
			}else{
				speedSet(speed);
			}
		}
	}
}

static void discoveryMode(){
	// TODO: change the speeds, last tire pos, and the number of repetitions
	//static uint8_t turn_actions[3][3] = {{0, 90, 45}, {10, 10, 10}, {20, 3, 100}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][2] = {{90, 45}, {24, 24}, {180, 500}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 2){
		if (turn_count == 2){ move_dir = 1; }
		if (turn_count == 3){ move_dir = 0; }
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}else{
			--repetitions;
		}
	}else{
		turn_count = -1;
		repetitions = -1;
		modeAction = accuracyMode;
	}

	if(lineVisible() && turn_count > 0){ modeAction = accuracyMode; }
}

static void manualMode(){
	//steerSet(bluetooth_tire_pos());
	//speedSet(bluetooth_speed());
}

#endif /* SRC_MODES_H_ */
