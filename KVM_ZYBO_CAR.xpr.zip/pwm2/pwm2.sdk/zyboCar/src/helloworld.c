/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h> // exit
#include <unistd.h> // sleep

#include "platform.h"
#include "xil_printf.h"

#include "xscugic.h"
#include "xgpio.h"
#include "xparameters.h"
#include "xil_exception.h"
//#include "sleep.h" // sleep?

#include "modes.h"
#include "buttons_and_leds.h"
#include "timer_and_pwm.h"
#include "motor_and_steering.h"
#include "linescan.h"
#include "lidar.h"

static void initializeSystem();
static void buttonLedInit();
static void motorSteeringInit();
static void lineScanInit();
static void pixyInit();
static void lidarInit();

int main()
{
	//int i = 0;
	initializeSystem();

	while(1){
		while(!go_flag){setMode();}
		setMode();
		go_flag = 0;

		while(!mode_finished){
			modeAction();
			usleep(20*1000);
		}
		modeAction = doNothingMode;
		modeAction();
		track_laps = 0;
		mode_finished = 0;
	}

    cleanup_platform();
    return 0;
}

static void initializeSystem(){
	init_platform();
	//print("Initializing Car\n\r");

	modeAction = doNothingMode;

	// Init GIC
	GicSetup(&Intc);

	buttonLedInit();
	motorSteeringInit();
	lineScanInit();
	pixyInit();
	lidarInit();

	initializeTimerSystem();

	// Enable interrupts in the Processor.
	Xil_ExceptionEnableMask(XIL_EXCEPTION_IRQ);


}

static void buttonLedInit(){
	// Init Buttons and LEDs
	initButtonsAndLeds();
}

static void motorSteeringInit(){
	// Init PWMs
	initSteerAndMotor();
}

static void lineScanInit(){
	// Init PWMs
	setupLineScanTimers();
	int status = initializeXADC();
	if(status != 0){
		printf("Error in XADC initialization: %d", status);
		exit(1);
	}
}

static void pixyInit(){

}

static void lidarInit(){

}







