/*
 * lidar.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_LIDAR_H_
#define SRC_LIDAR_H_

static int colPidOut();

static int colPidOut(){
	return 5;
}

#endif /* SRC_LIDAR_H_ */
