/*
 * pwm.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_MOTOR_AND_STEERING_H_
#define SRC_MOTOR_AND_STEERING_H_

#include "xparameters.h"
#include "PWM.h"
#include "timer_and_pwm.h"

#define PWM0_BASEADDR	XPAR_PWM_0_PWM_AXI_BASEADDR
#define PWM1_BASEADDR	XPAR_PWM_1_PWM_AXI_BASEADDR

#define PWM_BASE_FREQ 	(100000000U)
#define MOTOR_PWM_FREQ	(20000U)
#define STEER_PWM_FREQ	(50U)

#define MOTOR_PWM_PERIOD 	(PWM_BASE_FREQ / MOTOR_PWM_FREQ)
#define STEER_PWM_PERIOD 	(PWM_BASE_FREQ / STEER_PWM_FREQ)

static void initSteerAndMotor();
static void updateMotorPwm(double duty_cycle);
static void updateSteerPwm(double duty_cycle);
static void speedSet(double speed);
static void steerSet(double angle);

double duty_cycle_per_angle;

static void initSteerAndMotor(){
    double pwm0_duty_cycle = 0;
    double pwm1_duty_cycle = .075;

    duty_cycle_per_angle = 5.0/180.0;

    PWM_Set_Period(PWM0_BASEADDR, MOTOR_PWM_PERIOD);
    PWM_Set_Period(PWM1_BASEADDR, STEER_PWM_PERIOD);

    PWM_Set_Duty(PWM0_BASEADDR,(u32)(pwm0_duty_cycle*MOTOR_PWM_PERIOD),0);
    PWM_Set_Duty(PWM1_BASEADDR,(u32)(pwm1_duty_cycle*STEER_PWM_PERIOD),0);

    PWM_Enable(PWM0_BASEADDR);
    PWM_Enable(PWM1_BASEADDR);
}

static void updateMotorPwm(double duty_cycle){
	PWM_Set_Duty(PWM0_BASEADDR,(u32)((duty_cycle/100)*MOTOR_PWM_PERIOD),0);
	//printf("motor duty cycle: %d\r\n", duty_cycle);
}

static void updateSteerPwm(double duty_cycle){
	PWM_Set_Duty(PWM1_BASEADDR,(u32)((duty_cycle/100)*STEER_PWM_PERIOD),0);
	//printf("steer duty cycle: %d\r\n", duty_cycle);
}

static void speedSet(double speed){ // speed between 0 and 100
	//updatePwmDutyCycle(speed, timer);
	updateMotorPwm(speed);
}

static void steerSet(double angle){ // angle between -90 and 90
	//int interval = 5; int center = 7.5;
	//int duty_cycle_per_angle = interval / 180;
	//int match = duty_cycle_per_angle * angle + center;
	//updatePwmDutyCycle(duty_cycle_per_angle * angle + 7.5, timer);
	updateSteerPwm(duty_cycle_per_angle * angle + 7.5);
}

#endif /* SRC_MOTOR_AND_STEERING_H_ */
