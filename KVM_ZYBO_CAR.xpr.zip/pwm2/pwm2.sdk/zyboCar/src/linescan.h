/*
 * linescan.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_LINESCAN_H_
#define SRC_LINESCAN_H_

#include "timer_and_pwm.h"

#define SYSMON_DEVICE_ID	XPAR_SYSMON_0_DEVICE_ID
#define PS7_XADC_DEVICE_ID  XPAR_PS7_XADC_0_DEVICE_ID

static int setupLineScanTimers();
static void lineScanSiHandler(void *CallBackRef);
static void lineScanClkHandler(void *CallBackRef);
static void line_eval();

static int steerPidOut();
int initializeXADC();
u32 singleReading();

XTtcPs line_scan_si, line_scan_clk;
int count = 0;
u32 line_scan_data[128];
u32 line_scan_temp[128];
u32 address;

int intersect_seen = 0;
int prev_intersect_seen = 0;
int stop_line_seen = 0;
int track_laps = 0;

int min_val = 5;
int max_val = 122;
int i;

int num_black_sections = 0;
int longest_black_section = 0;
int num_outliers = 3;
int length_black_section = 0;
int length_white_section = 0;
int in_black_section = 0;

int num_long_black_sections = 0;
int long_section = 15;

int tire_pos = 0;

int line_start, line_end, line_center;

XAdcPs  XADCMonInst;
XAdcPs_Config *XADCConfigPtr;
XAdcPs *XADCInstPtr = &XADCMonInst;

XSysMon SysMonInst;
XSysMon_Config *SYSConfigPtr ;
XSysMon* SysMonInstPtr = &SysMonInst;

static int setupLineScanTimers(){
	u16 options;
	int ret;

	ret = genTimer(40, &line_scan_si, &lineScanSiHandler);
	if (ret < 0) { return ret; }
	XTtcPs_EnableInterrupts(&line_scan_si, XTTCPS_IXR_MATCH_0_MASK);
	options =  XTtcPs_GetOptions(&line_scan_si) | XTTCPS_OPTION_MATCH_MODE;
	XTtcPs_SetOptions(&line_scan_si, options);
	updatePwmDutyCycle(0.135, &line_scan_si);

	ret = genTimer(20000, &line_scan_clk, &lineScanClkHandler);
	if (ret < 0) { return ret; }
	XTtcPs_EnableInterrupts(&line_scan_clk, XTTCPS_IXR_MATCH_0_MASK);
	options =  XTtcPs_GetOptions(&line_scan_clk) | XTTCPS_OPTION_MATCH_MODE;
	XTtcPs_SetOptions(&line_scan_clk, options);
	updatePwmDutyCycle(50, &line_scan_clk);

	return 0;
}

static void lineScanSiHandler(void *CallBackRef)
{
	u32 StatusEvent;

	StatusEvent = XTtcPs_GetInterruptStatus((XTtcPs *)CallBackRef);
	XTtcPs_ClearInterruptStatus((XTtcPs *)CallBackRef, StatusEvent);

	if (0 != (XTTCPS_IXR_INTERVAL_MASK & StatusEvent)) {
		XTtcPs_Start(&line_scan_clk);
	}
}

static void lineScanClkHandler(void *CallBackRef)
{
	u32 StatusEvent;

	StatusEvent = XTtcPs_GetInterruptStatus((XTtcPs *)CallBackRef);
	XTtcPs_ClearInterruptStatus((XTtcPs *)CallBackRef, StatusEvent);

	if (0 != (XTTCPS_IXR_MATCH_0_MASK & StatusEvent)) {
		line_scan_data[count] = singleReading();
		if (line_scan_data[count] < 28000 && count > 4 && count < 123){
			line_scan_data[count] = 0;
		}else {
			line_scan_data[count] = 1;
		}
		count++;
	}

	if(count == 129){
		XTtcPs_Stop(&line_scan_clk);
		line_eval();
		count = 0;
	}
}

static int steerPidOut(){
	//line_start = 0, line_end = 0, line_center = 0;

	while(count != 0){}

	line_start = 0;
	for(i = 5; i < 123; ++i){
		if((line_scan_data[i] == 0) && (line_start == 0)){
			line_start = i;
		}
		if((line_scan_data[i] == 0) && ((line_scan_data[i+1] == 1) || (i == 117))){
			line_end = i;
		}
		line_center = ((line_end - line_start) / 2) + line_start;
	}

	if(line_center == 0){} //do nothing
	else{
		tire_pos = ((59 - line_center) * 0.042) / (duty_cycle_per_angle); // TODO: Change
		//updateSteerPwm(7.5 + (59 - line_center) * 0.042);
		//printf(" vals: %d, %d, %d, %d\r\n", line_end, line_start, line_center, tire_pos);
	}

	return tire_pos;
}

static void line_eval(){
	int line_center_temp = 0;
	int start_black_section = 0;
	longest_black_section = 0;
	num_long_black_sections = 0;

	for(i = min_val; i < max_val; ++i){ // For input (ends cut off)
	    //printf("%lu", line_scan_data[i]); // DEBUG
	    if(line_scan_data[i] == 0){ // If it's a black pixel
	      ++length_black_section;
	      if(!in_black_section){ // If it's a white section
	        if(length_black_section > num_outliers){ // If it's a new black section
	          in_black_section = 1;
	          ++num_black_sections;
	          length_white_section = 0;
	          start_black_section = i - num_outliers;
	          //printf(" B"); // DEBUG
	        }
	      }else{ // Reset length on false alarm from outliers
	        length_white_section = 0;
	      }
	    }else{ // If it's a white pixel
	      ++length_white_section;
	      if(in_black_section){ // If it's a black section
	        if(length_white_section > num_outliers){ // If it's a new white section
	          in_black_section = 0;
	          if(length_black_section > longest_black_section){ // Update longest black section
	            longest_black_section = length_black_section; // TODO: Put in an array of lengths?
	            //printf(" L (%d)", longest_black_section); // DEBUG
	            line_center_temp = ((i - num_outliers) - start_black_section) / 2 + start_black_section;
	          }
	          if(length_black_section > long_section){ ++num_long_black_sections; }
	          length_black_section = 0;
	          //printf(" W"); // DEBUG
	        }
	      }else{ // Reset length on false alarm from outliers
	        length_black_section = 0;
	      }
	    }

	    if(i == (max_val-1) && in_black_section){ // Ends in a black section
	      if(length_black_section > longest_black_section){ // Update longest black section
	        longest_black_section = length_black_section; // TODO: Put in an array of lengths?
	        //printf(" L (%d)", longest_black_section); // DEBUG
	        line_center_temp = ((i - num_outliers) - start_black_section) / 2 + start_black_section;
	      }
	      if(length_black_section > long_section){ ++num_long_black_sections; }
	    }
	    //printf(", "); // DEBUG
	}

	//if(longest_black_section > 10 && (line_center_temp > 5 && line_center_temp < 122) ){ line_center = line_center_temp; }

	if(num_long_black_sections == 3 && !intersect_seen){
		if(!prev_intersect_seen){
			stop_line_seen = 1;
			++track_laps;
		}
		prev_intersect_seen = 1;
	  }else if(longest_black_section > 100 && !stop_line_seen){
		intersect_seen = 1;
		prev_intersect_seen = 0;
	  }else{
		intersect_seen = 0;
		stop_line_seen = 0;
		prev_intersect_seen = 0;
	  }

	  /*printf("\nlongest_black_section: %d\nnum_long_black_sections: %d\nintersect_seen: %d\nstop_line_seen: %d\n\n",
	            longest_black_section, num_long_black_sections, intersect_seen, stop_line_seen); // DEBUG
		*/
}

int lineVisible(){ return longest_black_section > 10 ? 1 : 0; }

int initializeXADC(){
    SYSConfigPtr = XSysMon_LookupConfig(SYSMON_DEVICE_ID);
	if (SYSConfigPtr == NULL) { return XST_FAILURE; }

    XSysMon_CfgInitialize(SysMonInstPtr, SYSConfigPtr, SYSConfigPtr->BaseAddress);
    address = SYSConfigPtr->BaseAddress;
    printf("XADC using Sysmon -> base address %lx \n\r", address);

    XADCConfigPtr = XAdcPs_LookupConfig(PS7_XADC_DEVICE_ID);
	if (XADCConfigPtr == NULL) { return XST_FAILURE+1; }
    XAdcPs_CfgInitialize(XADCInstPtr,XADCConfigPtr,XADCConfigPtr->BaseAddress);

    address = XADCConfigPtr->BaseAddress;
    printf("XADC using XADPS -> base address %lx \n\r", address);

    return 0;
}

u32 singleReading(){
	XSysMon_StartAdcConversion(&SysMonInst);
	return(XSysMon_GetAdcData(&SysMonInst, XADCPS_AUX14_OFFSET));
}

#endif /* SRC_LINESCAN_H_ */
