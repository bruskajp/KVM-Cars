/*
 * linescan.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_LINESCAN_H_
#define SRC_LINESCAN_H_


#include "fsl_adc16.h"

#include "timer_and_pwm.h"

/* Interrupt number and interrupt handler for the FTM instance used */
//#define FTM_INTERRUPT_NUMBER FTM3_IRQn
#define FTM_LineScan_Handler FTM3_IRQHandler

/* ADC ADC ADC ADC ADC ADC ADC ADC ADC */
#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL 12U /* PTB2, ADC0_SE12 */

ftm_config_t ftmInfo1;
ftm_config_t ftmInfo2;
ftm_chnl_pwm_signal_param_t ftmParam1;
ftm_chnl_pwm_signal_param_t ftmParam2;
ftm_pwm_level_select_t pwmLevel = kFTM_LowTrue;

volatile bool ftm_is_r_flag = false;
volatile uint8_t num_cycles = 0U;
volatile uint16_t num_outputs = 0U;
volatile double updated_duty_cycle = 7.5;
volatile double prev_duty_cycle = 7.5;
volatile int8_t line_error = 0;
volatile int8_t line_error_prev = 0;
volatile int8_t line_error_prev2 = 0;
volatile int8_t line_error_prev3 = 0;
volatile int8_t line_error_prev4 = 0;
volatile double pid_a = 0.028; // 0.042
volatile double pid_b = 0;
volatile double pid_c = 0.0015;
volatile int straight_away = 0;

volatile uint8_t line_start, line_center, line_end;

adc16_config_t adc16ConfigStruct;
adc16_channel_config_t adc16ChannelConfigStruct;

int count = 0;
int line_scan_temp[128];
int line_scan_data[128];
int address;

int intersect_seen = 0;
int prev_intersect_seen = 0;
int stop_line_seen = 0;
int track_laps = 0;

int min_val = 0;
int max_val = 117;

int num_black_sections = 0;
int longest_black_section = 0;
int num_outliers = 3;
int length_black_section = 0;
int length_white_section = 0;
int in_black_section = 0;

int num_long_black_sections = 0;
int long_section = 10;

int tire_pos = 0;

int setupLineScanTimers(){
	int i;

	/* Configure ftm params */
    ftmParam1.chnlNumber = kFTM_Chnl_7;   //Line scan CLK
    ftmParam1.level = pwmLevel;
    ftmParam1.dutyCyclePercent = 50U;
    ftmParam1.firstEdgeDelayPercent = 0U;

    ftmParam2.chnlNumber = kFTM_Chnl_6;   //Line scan SI
    ftmParam2.level = pwmLevel;
    ftmParam2.dutyCyclePercent = 50U;
    ftmParam2.firstEdgeDelayPercent = 0U;
	
	FTM_GetDefaultConfig(&ftmInfo1);
    FTM_GetDefaultConfig(&ftmInfo2);
	
	/* Initialize FTM module */
    FTM_Init(FTM3, &ftmInfo1);
    FTM_Init(FTM3, &ftmInfo2);
	
	FTM_SetupPwm(FTM3, &ftmParam1, 1U, kFTM_EdgeAlignedPwm, 20000U, FTM_SOURCE_CLOCK);
    FTM_SetupPwm(FTM3, &ftmParam2, 1U, kFTM_EdgeAlignedPwm, 20000U, FTM_SOURCE_CLOCK);

    for(i=0; i<128; ++i){ line_scan_data[i] = 100000; }

	return 0;
}

static void line_eval(){
	int line_center_temp = 0;
	int start_black_section = 0;
	num_black_sections = 0;
	longest_black_section = 0;
	num_long_black_sections = 0;

	int long_black_section_on_start = 0;
	int long_black_section_on_end = 0;

	for(i = min_val; i < max_val; ++i){ // For input (ends cut off)
	    //printf("%lu", line_scan_data[i]); // DEBUG
	    if(line_scan_data[i] == 0){ // If it's a black pixel
	      ++length_black_section;
	      if(!in_black_section){ // If it's a white section
	        if(length_black_section > num_outliers){ // If it's a new black section
	          in_black_section = 1;
	          ++num_black_sections;
	          length_white_section = 0;
	          start_black_section = i - num_outliers;
	          //printf(" B"); // DEBUG
	        }
	      }else{ // Reset length on false alarm from outliers
	        length_white_section = 0;
	      }
	    }else{ // If it's a white pixel
	      ++length_white_section;
	      if(in_black_section){ // If it's a black section
	        if(length_white_section > num_outliers){ // If it's a new white section
	          in_black_section = 0;
	          if(length_black_section > longest_black_section){ // Update longest black section
	            longest_black_section = length_black_section; // TODO: Put in an array of lengths?
	            //printf(" L (%d)", longest_black_section); // DEBUG
	            line_center_temp = ((i - num_outliers) - start_black_section) / 2 + start_black_section;
	          }
	          if(length_black_section > long_section){
	        	  ++num_long_black_sections;
	        	  if(start_black_section < 6){ long_black_section_on_start = 1; }
	          }
	          length_black_section = 0;
	          //printf(" W"); // DEBUG
	        }
	      }else{ // Reset length on false alarm from outliers
	        length_black_section = 0;
	      }
	    }

	    if(i == (max_val-1) && in_black_section){ // Ends in a black section
	      long_black_section_on_end = 1;
	      if(length_black_section > longest_black_section){ // Update longest black section
	        longest_black_section = length_black_section; // TODO: Put in an array of lengths?
	        //printf(" L (%d)", longest_black_section); // DEBUG
	        line_center_temp = ((i - num_outliers) - start_black_section) / 2 + start_black_section;
	      }
	      if(length_black_section > long_section){ ++num_long_black_sections; }
	    }
	    //printf(", "); // DEBUG
	}

	//if(longest_black_section > 10 && (line_center_temp > 5 && line_center_temp < 122) ){ line_center = line_center_temp; }

	if(num_long_black_sections == 3 && !intersect_seen && long_black_section_on_start && long_black_section_on_end){
		if(!prev_intersect_seen){
			stop_line_seen = 1;
			++track_laps;
		}
		prev_intersect_seen = 1;
	}else if(longest_black_section > 100 && !stop_line_seen){
		intersect_seen = 1;
		prev_intersect_seen = 0;
	}else{
		intersect_seen = 0;
		stop_line_seen = 0;
		prev_intersect_seen = 0;
	}

	  /*printf("\nlongest_black_section: %d\nnum_long_black_sections: %d\nintersect_seen: %d\nstop_line_seen: %d\n\n",
	            longest_black_section, num_long_black_sections, intersect_seen, stop_line_seen); // DEBUG
		*/
}

int lineVisible(){ return ((longest_black_section > 15) && (line_error < 10) && (line_error > -10)) ? 1 : 0; }

void FTM_LineScan_Handler(void)
{
	num_cycles++;

	if(num_cycles == 160U)//180
	{
		FTM_UpdateChnlEdgeLevelSelect(FTM3, kFTM_Chnl_6, 0U);
		FTM_UpdatePwmDutycycle(FTM3, kFTM_Chnl_6, kFTM_EdgeAlignedPwm, 100U);
		FTM_SetSoftwareTrigger(FTM3, true);
		FTM_UpdateChnlEdgeLevelSelect(FTM3, kFTM_Chnl_6, kFTM_LowTrue);
		num_cycles = 0;
		ftm_is_r_flag = true;
	}

	ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);

	if((num_outputs < 128U) & (ftm_is_r_flag == true))
	{
		line_scan_temp[num_outputs] = ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP);
		num_outputs++;
	}
	else
	{
		num_outputs = 0U;
		ftm_is_r_flag = false;

		for(int i = 5U; i < 123U; i++)
		{
			if(line_scan_temp[i] < 900U)
			{
				line_scan_data[i-5U] = 0U;
			}
			else
			{
				line_scan_data[i-5U] = 1U;
			}
		}
		line_eval();
	}
	if ((FTM_GetStatusFlags(FTM3) & kFTM_Chnl7Flag) == kFTM_Chnl7Flag)
	{
		/* Clear interrupt flag.*/
		FTM_ClearStatusFlags(FTM3, kFTM_Chnl7Flag);
	}
}


int isOnStraightAway(){
	return straight_away;
}

int steerPidOut(){
	int i;
	line_start = 0;
	line_end = 0;
	line_center = 0;

	while(count != 0){}

	for(i = 0; i < 118; ++i){
		if((line_scan_data[i] == 0) && (line_start == 0)){
			line_start = i;
		}
		if((line_scan_data[i] == 0) && ((line_scan_data[i+1U] == 1U) || (i == 117U))){
			line_end = i;
		}
		line_center = (line_start+line_end) / 2;
	}

	line_error_prev4 = line_error_prev3;
	line_error_prev3 = line_error_prev2;
	line_error_prev2 = line_error_prev;
	line_error_prev = line_error;
	line_error = line_center - 59;
	prev_duty_cycle = updated_duty_cycle;

	if(line_center == 0U)
	{
		if(prev_duty_cycle < 7.5){ updated_duty_cycle = 5.0; }
		else if(prev_duty_cycle > 7.5){ updated_duty_cycle = 10.0; }
		else{} //do nothing so it still continues the same direction it was
	}
	else
	{
		//updated_duty_cycle = (7.5 + (59 - line_center) * 0.042);
		updated_duty_cycle = (7.5 - (line_error * pid_a) - ((line_error + line_error_prev + line_error_prev2 + line_error_prev3 + line_error_prev4) * pid_b) - ((line_error - line_error_prev) * pid_c));
		if((line_error > 4) || (line_error < -8)){ straight_away = 0; }
		else { straight_away = 1; }

		if(updated_duty_cycle > 10.0) { updated_duty_cycle = 10.0; }
		else if(updated_duty_cycle < 5.0){ updated_duty_cycle = 5.0; }
	}
	tire_pos = (updated_duty_cycle - 7.5) / duty_cycle_per_angle;

	return tire_pos;
}

int initializeXADC(){
    ADC16_GetDefaultConfig(&adc16ConfigStruct);
    #ifdef BOARD_ADC_USE_ALT_VREF
        adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
    #endif
	ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
	ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */

	adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL;
	adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
    #if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
        adc16ChannelConfigStruct.enableDifferentialConversion = false;
    #endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */

    return 0;
}

#endif /* SRC_LINESCAN_H_ */
