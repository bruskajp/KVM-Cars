/*
 * modes.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_MODES_H_
#define SRC_MODES_H_

#include "pixy.h"
#include "motor_and_steering.h"
#include "lidar.h"
#include "linescan.h"
#include "buttons_and_leds.h"

static void setMode();

static void doNothingMode();
static void basicMode();
static void accuracyMode();
static void speedMode();
static void collisionMode();
static void discoveryMode();
static void manualMode();

static void turnRightSlow();
static void turnLeftSlow();
static void turnAroundSlow();

static void turnRightFast();
static void turnLeftFast();
static void turnAroundFast();

void (*modeAction)(void);
uint8_t mode_finished = 0;

int speed = 24;
extern int marker_sigs[2];

extern int intersect_seen;
uint8_t turning = 0;
int turn_count = -1;
int repetitions = -1;
extern int track_laps;
uint8_t car_ahead = 0;
uint8_t line_seen = 0;
int starting = 0;

static void setMode(){
	if (mode_count == 0){
		modeAction = doNothingMode;
		LED_RED_ON();
		LED_GREEN_OFF();	//Red
		LED_BLUE_OFF();
	}else if (mode_count == 1){
		modeAction = basicMode;
		speed = 22;
		LED_RED_ON();
		LED_GREEN_ON();		//White
		LED_BLUE_ON();
	}else if (mode_count == 2){
		modeAction = accuracyMode;
		speed = 24;
		LED_RED_OFF();
		LED_GREEN_OFF();	//Blue
		LED_BLUE_ON();
	}else if (mode_count == 3){
		modeAction = speedMode;
		speed = 26;
		LED_RED_OFF();
		LED_GREEN_ON();		//Green
		LED_BLUE_OFF();
	}else if (mode_count == 4){
		modeAction = collisionMode;
		speed = 28;
		LED_RED_ON();
		LED_GREEN_ON();		//Yellow
		LED_BLUE_OFF();
	}else if (mode_count == 5){
		modeAction = discoveryMode;
		LED_RED_ON();
		LED_GREEN_OFF();	//Purple
		LED_BLUE_ON();
	}else if (mode_count == 6){
		modeAction = manualMode;
		LED_RED_OFF();
		LED_GREEN_ON();	//Cyan
		LED_BLUE_ON();
	}
}

void turnRightSlow(){
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][1] = {{-90}, {22}, {110}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 1){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}
		else{
			--repetitions;
		}
	}
	else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

void turnLeftSlow(){
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][1] = {{90}, {22}, {110}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 1){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}
		else{
			--repetitions;
		}
	}
	else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

void turnAroundSlow(){
	// TODO: change the speeds and the number of repetitions
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][3] = {{-90, 90, 0}, {20, 25, 1}, {100, 200, 40}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 3){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (turn_count == 1){
			setReverseDir();
		}
		if (turn_count == 2){
			setForwardDir();
		}
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}
		else{
			--repetitions;
		}
	}
	else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

void turnRightFast(){
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][1] = {{-90}, {22}, {140}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 1){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}
		else{
			--repetitions;
		}
	}
	else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

void turnLeftFast(){
	//static int turn_actions[3][3] = {{0, -90, 0}, {1, 1, 1}, {2, 100, 2}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][2] = {{90, -90}, {22, 16}, {140, 30}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 1){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}
		else{
			--repetitions;
		}
	}
	else{
		turn_count = -1;
		repetitions = -1;
		turning = 0;
	}
}

void turnAroundFast(){
	// THIS WILL NOT BE TESTED
	turn_count = -1;
	repetitions = -1;
	turning = 0;
}

void doNothingMode(){
	speedSet(0);
	steerSet(0);
}

void basicMode(){
	pixyRead();
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){
				turnAroundSlow();
			}
			else{
				turnLeftSlow();
			}
		}
		else{
			if(marker_sigs[1]){
				turnRightSlow();
			}
			else{
				turning = 0;
			}
		}
	}
	else{
		steerSet(steerPidOut());
		speedSet(speed);
		if(markers_opposite){
			if(intersect_seen){
				markers_opposite = 0;
				if(!markers_visible){
					turning = 1;
				}
			}
			else{
				if(speed > 24){
					speed -= 1;
				}
			}
		}
		else{
			if(speed < 26){
				speed +=1;
			}
		}
	}
}

void accuracyMode(){
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){
				turnAroundSlow();
			}
			else{
				turnLeftSlow();
			}
		}
		else{
			if(marker_sigs[1]){
				turnRightSlow();
			}
			else{
				turning = 0;
			}
		}
	}
	else{
		steerSet(steerPidOut());
		speedSet(speed);
		if(track_laps >= 2){
			mode_finished = 1;
			modeAction = doNothingMode;
		}
		if(markers_opposite){
			if(intersect_seen){
				markers_opposite = 0;
				if(!markers_visible){
					turning = 1;
				}
			}
			else{
				if(speed > 22){
					speed -= 1;
				}
			}
		}
		else{
			if(speed < 22){
				speed +=1;
			};
		}
	}
}

void speedMode(){
	if(turning){
		if(marker_sigs[0]){
			if(marker_sigs[1]){
				turnAroundFast();
			}
			else{
				turnLeftFast();
			}
		}
		else{
			if(marker_sigs[1]){
				turnRightFast();
			}
			else{
				turning = 0;
			}
		}
	}
	else{
		steerSet(steerPidOut());
		speedSet(speed);
		if(track_laps >= 2){
			mode_finished = 1;
		}
		if(markers_opposite){
			if(intersect_seen){
				markers_opposite = 0;
				if(!markers_visible){
					turning = 1;
				}
			}
			else{
				if(speed > 24){
					speed -= 1;
				}
			}
		}
		else{
			if(isOnStraightAway()){
				if(speed < 50){
					speed += 1;
				}
			}
			else{
				if(speed > 26){
					speed -= 1;
				}
			}
		}
	}
}

void collisionMode(){
	if (starting){
		starting = 0;
		collisionModeSpeed(100);
	}
	if(turning){
		if(marker_sigs[0]){
			if(!marker_sigs[1]){
				turnLeftSlow();
			}
		}
		else{
			if(marker_sigs[1]){
				turnRightSlow();
			}
			else{
				turning = 0;
			}
		}
	}else{
		steerSet(steerPidOut());
		if(track_laps >= 2){
			mode_finished = 1;
		}
		if(markers_opposite){
			if(intersect_seen){
				markers_opposite = 0;
				if(!markers_visible){
					turning = 1;
				}
			}
		}
	}
//	if (masterRxInfo[0][1] == 28 && masterRxData[0] == 0){
//		//collisionModeSpeed(25);
//	}
//	else if (masterRxInfo[0][1] == 28 || masterRxInfo[1][1] == 28){
//		collisionModeSpeed(distance);
//	}

}

void discoveryMode(){
	// TODO: change the speeds, last tire pos, and the number of repetitions
	//static int turn_actions[3][2] = {{90, 45}, {28, 28}, {180, 500}}; // [[tire angles], [speeds], [repetitions]]
	static int turn_actions[3][2] = {{90, 45}, {28, 28}, {301, 1000}}; // [[tire angles], [speeds], [repetitions]]
	if(turn_count == -1 && repetitions == -1){
		turn_count = 0;
		repetitions = turn_actions[2][0];
	}
	if (turn_count < 2){
		steerSet(turn_actions[0][turn_count]);
		speedSet(turn_actions[1][turn_count]);
		if (repetitions <= 0){
			++turn_count;
			repetitions = turn_actions[2][turn_count];
		}else{
			--repetitions;
		}
	}else{
		turn_count = -1;
		repetitions = -1;
		modeAction = doNothingMode;
	}

	if(lineVisible() && turn_count > 0){
		modeAction = accuracyMode;
	}
}

void manualMode(){
	//steerSet(bluetooth_tire_pos());
	//speedSet(bluetooth_speed());
}

#endif /* SRC_MODES_H_ */
