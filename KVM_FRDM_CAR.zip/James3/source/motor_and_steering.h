/*
 * pwm.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_MOTOR_AND_STEERING_H_
#define SRC_MOTOR_AND_STEERING_H_

#include "timer_and_pwm.h"
#include <math.h>

/* Interrupt number and interrupt handler for the FTM instance used */
#define SteeringPWM_HANDLER FTM0_IRQHandler

ftm_config_t ftmInfo3;
ftm_config_t ftmInfo4;
ftm_chnl_pwm_signal_param_t ftmParam3;
ftm_chnl_pwm_signal_param_t ftmParam4;
gpio_pin_config_t dir_config = { // steering
            kGPIO_DigitalOutput, 0
        };

double cSpeed = 30;

void initSteerAndMotor(){

	ftmParam3.chnlNumber = kFTM_Chnl_1;   //Steering Servo
	ftmParam3.level = kFTM_HighTrue;
	ftmParam3.dutyCyclePercent = 7U;
	ftmParam3.firstEdgeDelayPercent = 0U;

	ftmParam4.chnlNumber = kFTM_Chnl_4;   //Motor
	ftmParam4.level = kFTM_HighTrue;
	ftmParam4.dutyCyclePercent = 0U;
	ftmParam4.firstEdgeDelayPercent = 0U;
	
	FTM_GetDefaultConfig(&ftmInfo3);
    FTM_GetDefaultConfig(&ftmInfo4);
	
	ftmInfo3.prescale = kFTM_Prescale_Divide_128; //must be done after default config
	
	/* Initialize FTM module */
	FTM_Init(FTM0, &ftmInfo3);
    FTM_Init(FTM3, &ftmInfo4);
	
	FTM_SetupPwm(FTM0, &ftmParam3, 1U, kFTM_EdgeAlignedPwm, 50U, FTM_SOURCE_CLOCK);
    FTM_SetupPwm(FTM3, &ftmParam4, 1U, kFTM_EdgeAlignedPwm, 20000U, FTM_SOURCE_CLOCK);
	
	GPIO_PinInit(GPIOC, 1U, &dir_config); //Initialize GPIO Pin PTC1
}

void updateMotorPwm(double duty_cycle){
	/* Disable interrupt to retain current dutycycle for a few seconds */
	//FTM_DisableInterrupts(FTM3, kFTM_Chnl4InterruptEnable);

	/* Disable channel output before updating the dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(FTM3, kFTM_Chnl_4, 0U);

	/* Update PWM duty cycle */
	FTM_UpdateDutyCycleDec(FTM3, kFTM_Chnl_4, kFTM_EdgeAlignedPwm, duty_cycle);

	/* Software trigger to update registers */
	//FTM_SetSoftwareTrigger(FTM3, true);

	/* Start channel output with updated dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(FTM3, kFTM_Chnl_4, kFTM_HighTrue);
	
	/* Enable interrupt flag to update PWM dutycycle */
	//FTM_EnableInterrupts(FTM3, kFTM_Chnl4InterruptEnable);
}

void updateSteerPwm(double duty_cycle){
	/* Disable interrupt to retain current dutycycle for a few seconds */
	FTM_DisableInterrupts(FTM0, kFTM_Chnl1InterruptEnable);

	/* Disable channel output before updating the dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(FTM0, kFTM_Chnl_1, 0U);

	/* Update PWM duty cycle */
	FTM_UpdateDutyCycleDec(FTM0, kFTM_Chnl_1, kFTM_EdgeAlignedPwm, duty_cycle);

	/* Software trigger to update registers */
	FTM_SetSoftwareTrigger(FTM0, true);

	/* Start channel output with updated dutycycle */
	FTM_UpdateChnlEdgeLevelSelect(FTM0, kFTM_Chnl_1, kFTM_HighTrue);

	/* Enable interrupt flag to update PWM dutycycle */
	FTM_EnableInterrupts(FTM0, kFTM_Chnl1InterruptEnable);
}

void speedSet(double speed){ // speed between 0 and 100
	updateMotorPwm(speed);
}

void steerSet(double angle){ // angle between -90 and 90
	//int interval = 5; int center = 7.5;
	//int duty_cycle_per_angle = interval / 180;
	//int match = duty_cycle_per_angle * angle + center;
	updateSteerPwm(duty_cycle_per_angle * angle + 7.5);
}

void SteeringPWM_HANDLER(void)
{
    if ((FTM_GetStatusFlags(FTM0) & kFTM_Chnl1Flag) == kFTM_Chnl1Flag)
    {
        /* Clear interrupt flag.*/
        FTM_ClearStatusFlags(FTM0, kFTM_Chnl1Flag);
    }
}

void setForwardDir(){
	GPIO_WritePinOutput(GPIOC, 1U, 0U);
}

void setReverseDir(){
	GPIO_WritePinOutput(GPIOC, 1U, 1U);
}

void collisionModeSpeed(double distance){
	if (distance > 36)
		distance = 36;
	else if (distance < 15)
		distance = 15;
	cSpeed = (-0.016 * pow(distance, 3)) + (1.0895 * pow(distance, 2)) - (21.06 * distance) + 124.11;
	if (cSpeed > 30)
		cSpeed = 30;
	else if (cSpeed < 0)
		cSpeed = 0 ;
	speedSet(cSpeed);
}


#endif /* SRC_MOTOR_AND_STEERING_H_ */
