/*
 * timer_and_pwm.h
 *
 *  Created on: Nov 20, 2017
 *      Author: ulab
 */

#ifndef SRC_BUTTONS_AND_LEDS_H_
#define SRC_BUTTONS_AND_LEDS_H_

#include "fsl_debug_console.h"
#include "fsl_port.h"
#include "fsl_gpio.h"
#include "fsl_common.h"
#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"

#define modeChangeHandler BOARD_SW3_IRQ_HANDLER
#define modeEnableHandler BOARD_SW2_IRQ_HANDLER

/* Whether the SW button is pressed */
int mode_count = 0;
bool go_flag = 0;

void modeChangeHandler(void)
{
    /* Clear external interrupt flag. */
    GPIO_ClearPinsInterruptFlags(BOARD_SW3_GPIO, 1U << BOARD_SW3_GPIO_PIN);
	if (mode_count == 6) {
		mode_count = 0;
	} else {
		mode_count = mode_count + 1;
	}
}

void modeEnableHandler(void)
{
    /* Clear external interrupt flag. */
    GPIO_ClearPinsInterruptFlags(BOARD_SW2_GPIO, 1U << BOARD_SW2_GPIO_PIN);

    if (go_flag == 0){
		go_flag = 1;
	} else {
		go_flag = 0;
	}
}

int initButtonAndLEDs(void)
{
    /* Define the init structure for the input switch pin */
    gpio_pin_config_t sw_config = {
        kGPIO_DigitalInput, 0,
    };

    /* Init input switch GPIO. */
    PORT_SetPinInterruptConfig(BOARD_SW3_PORT, BOARD_SW3_GPIO_PIN, kPORT_InterruptFallingEdge);
    EnableIRQ(BOARD_SW3_IRQ);
    GPIO_PinInit(BOARD_SW3_GPIO, BOARD_SW3_GPIO_PIN, &sw_config);

    /* Init input switch GPIO. */
	PORT_SetPinInterruptConfig(BOARD_SW2_PORT, BOARD_SW2_GPIO_PIN, kPORT_InterruptFallingEdge);
	EnableIRQ(BOARD_SW2_IRQ);
	GPIO_PinInit(BOARD_SW2_GPIO, BOARD_SW2_GPIO_PIN, &sw_config);

}

#endif /* SRC_BUTTONS_AND_LEDS_H_ */
