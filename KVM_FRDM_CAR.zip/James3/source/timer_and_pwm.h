/*
 * timer_and_pwm.h
 *
 *  Created on: Nov 20, 2017
 *      Author: ulab
 */

#ifndef SRC_TIMER_AND_PWM_H_
#define SRC_TIMER_AND_PWM_H_

/* Get source clock for FTM driver */
#define FTM_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)

#include "fsl_ftm.h"

/* The Flextimer instance/channel used for board */
//#define BOARD_FTM_BASEADDR FTM3

/* Interrupt to enable and flag to read; depends on the FTM channel used */
//#define FTM_CHANNEL_INTERRUPT_ENABLE kFTM_Chnl0InterruptEnable
//#define FTM_CHANNEL_FLAG kFTM_Chnl0Flag

double duty_cycle_per_angle = 5.0/180.0;

void initializeTimerSystem(){
	/* Enable FTM channel interrupt flag.*/
    FTM_EnableInterrupts(FTM3, kFTM_Chnl7InterruptEnable);
    FTM_EnableInterrupts(FTM0, kFTM_Chnl1InterruptEnable);

    /* Enable at the NVIC */
    EnableIRQ(FTM3_IRQn);
    EnableIRQ(FTM0_IRQn);

    FTM_StartTimer(FTM3, kFTM_SystemClock);
    FTM_StartTimer(FTM0, kFTM_SystemClock);
}

void FTM_UpdateDutyCycleDec(FTM_Type *base,
                            ftm_chnl_t chnlNumber,
                            ftm_pwm_mode_t currentPwmMode,
                            double dutyCyclePercent)
{
    uint16_t cnv, cnvFirstEdge = 0, mod;

    mod = base->MOD;
    if ((currentPwmMode == kFTM_EdgeAlignedPwm) || (currentPwmMode == kFTM_CenterAlignedPwm))
    {
        cnv = (mod * dutyCyclePercent) / 100;
        /* For 100% duty cycle */
        if (cnv >= mod)
        {
            cnv = mod + 1;
        }
        base->CONTROLS[chnlNumber].CnV = cnv;
    }
    else
    {
        /* This check is added for combined mode as the channel number should be the pair number */
        if (chnlNumber >= (FSL_FEATURE_FTM_CHANNEL_COUNTn(base) / 2))
        {
            return;
        }

        cnv = (mod * dutyCyclePercent) / 100;
        cnvFirstEdge = base->CONTROLS[chnlNumber * 2].CnV;
        /* For 100% duty cycle */
        if (cnv >= mod)
        {
            cnv = mod + 1;
        }
        base->CONTROLS[(chnlNumber * 2) + 1].CnV = cnvFirstEdge + cnv;
    }
}

//void delay(void)
//{
//    volatile uint32_t i = 0U;
//    for (i = 0U; i < 60000U; ++i)
//    {
//        __asm("NOP"); /* delay */
//    }
//}

#endif /* SRC_TIMER_AND_PWM_H_ */
