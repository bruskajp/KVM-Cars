/*
 * lidar.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_LIDAR_H_
#define SRC_LIDAR_H_

int colPidOut(){
	return 5;
}

#endif /* SRC_LIDAR_H_ */
