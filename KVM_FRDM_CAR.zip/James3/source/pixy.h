/*
 * pixy.h
 *
 *  Created on: Nov 21, 2017
 *      Author: ulab
 */

#ifndef SRC_PIXY_H_
#define SRC_PIXY_H_

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "fsl_dspi.h"
#include "board.h"
#include <math.h>

#include "pin_mux.h"
#include "clock_config.h"

#define EXAMPLE_DSPI_MASTER_BASEADDR SPI0
#define EXAMPLE_DSPI_MASTER_CLK_SRC DSPI0_CLK_SRC
#define EXAMPLE_DSPI_MASTER_CLK_FREQ CLOCK_GetFreq(DSPI0_CLK_SRC)
#define EXAMPLE_DSPI_MASTER_IRQ SPI0_IRQn
#define EXAMPLE_DSPI_MASTER_PCS kDSPI_Pcs0
#define EXAMPLE_DSPI_MASTER_IRQHandler SPI0_IRQHandler

#define TRANSFER_SIZE 1U        /*! Transfer dataSize */
#define TRANSFER_BAUDRATE 115200U /*! Transfer baudrate - 500k */

uint16_t masterRxData[TRANSFER_SIZE] = {0U};
uint8_t masterTxData[TRANSFER_SIZE] = {0U};

volatile uint32_t masterTxCount;
volatile uint32_t masterRxCount;
volatile uint32_t masterCommand;
uint32_t masterFifoSize;

dspi_master_handle_t g_m_handle;

volatile bool isTransferCompleted = false;

int16_t masterRxInfo[2][7] = {0U};
char masterRxString [4];

int poleNum = -1;
int poleAttr = -1;
uint8_t useless = 0;
int markers_visible = 0;
int markers_opposite = 0;
int marker_sigs[2] = {-1,-1};
int half_width = 128;

double distance = 0.0;
int height = 0;

dspi_command_data_config_t commandData;

uint32_t srcClock_Hz;
uint32_t errorCount;
uint32_t i;
dspi_master_config_t masterConfig;

static void delay(volatile uint32_t nof) {
  while(nof!=0) {
    __asm("NOP");
    nof--;
  }
}

void createArray(int masterRxCount){

	if (strcmp(masterRxString,"aa55") == 0){
		if (masterRxInfo[1][1] == 0){
			markers_visible = 0;
		}
		else if (masterRxInfo[1][1] != 0){
			markers_visible = 1;
			if(masterRxInfo[0][1] > 0 && masterRxInfo[1][1] > 0){ // check if there are two markers
				if(masterRxInfo[0][2] < half_width && masterRxInfo[1][2] > half_width){ // marker 1 on left and marker 2 on right
					markers_opposite = 1;
					if(masterRxInfo[0][1] == 10){
						marker_sigs[0] = 0;
					}
					else if(masterRxInfo[0][1] == 11){
						marker_sigs[0] = 1;
					}

					if(masterRxInfo[1][1] == 10){
						marker_sigs[1] = 0;
					}
					else if(masterRxInfo[1][1] == 11){
						marker_sigs[1] = 1;
					}
				}
				else if(masterRxInfo[0][2] > half_width && masterRxInfo[1][2] < half_width){ // marker 1 on right and marker 2 on left
					markers_opposite = 1;
					if(masterRxInfo[0][1] == 10){
						marker_sigs[1] = 0;
					}
					else if(masterRxInfo[0][1] == 11){
						marker_sigs[1] = 1;
					}

					if(masterRxInfo[1][1] == 10){
						marker_sigs[0] = 0;
					}
					else if(masterRxInfo[1][1] == 11){
						marker_sigs[0] = 1;
					}
				}
				else{
					markers_opposite = 0;
				}
			}
		}

		if (marker_sigs[1] == 1 && marker_sigs[0] == 0){//LEFT [RED]
			LED_RED_ON();
			LED_GREEN_OFF();
			LED_BLUE_OFF();
		}
		else if (marker_sigs[1] == 0 && marker_sigs[0] == 1){//RIGHT [GREEN]
			LED_RED_OFF();
			LED_GREEN_ON();
			LED_BLUE_OFF();
		}
		else if (marker_sigs[1] == 1 && marker_sigs[0] == 1){//U TURN [BLUE]
			LED_RED_OFF();
			LED_GREEN_OFF();
			LED_BLUE_ON();
		}
		else if (marker_sigs[1] == 0 && marker_sigs[0] == 0){//STRAIGHT [WHITE]
			LED_RED_ON();
			LED_GREEN_ON();
			LED_BLUE_ON();
		}

		poleNum = 0;
		//masterRxInfo[1][1] = 0;
	}
	else if (strcmp(masterRxString,"aa56") == 0 && poleNum != -1){
		poleAttr = 0;
	}
	else if (masterRxData[0] == 0 && poleAttr == 0){
		markers_visible = 0;
	}
	else if (poleNum >= 0 && poleAttr >= 0){
		masterRxInfo[poleNum][poleAttr] = masterRxData[masterRxCount];
		poleAttr++;
	}

	if (poleAttr > 6){
		poleAttr = 0;
		poleNum++;
	}

	if (poleNum > 1){
		poleNum = -1;
	}

//	if (masterRxInfo[0][1] == 28 && masterRxData[0] == 0){
//		collisionModeSpeed(25);
//	}
	if (masterRxInfo[0][1] == 28){
		height = masterRxInfo[0][5];
		distance = 684.16 * pow(height,-0.987);
		collisionModeSpeed(distance);
	}
	else if (masterRxInfo[1][1] == 28){
		height = masterRxInfo[0][5];
		distance = 684.16 * pow(height,-0.987);
		collisionModeSpeed(distance);
	}

}




void EXAMPLE_DSPI_MASTER_IRQHandler(void)
{
    if (masterRxCount < TRANSFER_SIZE)
    {
        while (DSPI_GetStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR) & kDSPI_RxFifoDrainRequestFlag)
        {
            masterRxData[masterRxCount] = DSPI_ReadData(EXAMPLE_DSPI_MASTER_BASEADDR);

            itoa(masterRxData[masterRxCount],masterRxString,16);

            createArray(masterRxCount);

            ++masterRxCount;
            DSPI_ClearStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR, kDSPI_RxFifoDrainRequestFlag);

            if (masterRxCount == TRANSFER_SIZE)
            {
                masterRxCount = 0;
            	break;
            }
        }
    }

    if (masterTxCount < TRANSFER_SIZE)
    {
        while ((DSPI_GetStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR) & kDSPI_TxFifoFillRequestFlag) &&
               ((masterTxCount - masterRxCount) < masterFifoSize))
        {
            if (masterTxCount < TRANSFER_SIZE)
            {
                EXAMPLE_DSPI_MASTER_BASEADDR->PUSHR = masterCommand | masterTxData[masterTxCount];
                ++masterTxCount;
            }
            else
            {
                break;
            }

            /* Try to clear the TFFF; if the TX FIFO is full this will clear */
            DSPI_ClearStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR, kDSPI_TxFifoFillRequestFlag);
        }
    }

    /* Check if we're done with this transfer.*/
    if ((masterTxCount == TRANSFER_SIZE) && (masterRxCount == TRANSFER_SIZE))
    {
        /* Complete the transfer and disable the interrupts */
        DSPI_DisableInterrupts(EXAMPLE_DSPI_MASTER_BASEADDR,
                               kDSPI_RxFifoDrainRequestInterruptEnable | kDSPI_TxFifoFillRequestInterruptEnable);
    }
}

void initPixy(){
	useless = 0;

	/* Master config */
	masterConfig.whichCtar = kDSPI_Ctar0;
	masterConfig.ctarConfig.baudRate = TRANSFER_BAUDRATE;
	masterConfig.ctarConfig.bitsPerFrame = 16;
	masterConfig.ctarConfig.cpol = kDSPI_ClockPolarityActiveHigh;
	masterConfig.ctarConfig.cpha = kDSPI_ClockPhaseFirstEdge;
	masterConfig.ctarConfig.direction = kDSPI_MsbFirst;
	masterConfig.ctarConfig.pcsToSckDelayInNanoSec = 1000000000U / TRANSFER_BAUDRATE;
	masterConfig.ctarConfig.lastSckToPcsDelayInNanoSec = 1000000000U / TRANSFER_BAUDRATE;
	masterConfig.ctarConfig.betweenTransferDelayInNanoSec = 5000000000U / TRANSFER_BAUDRATE;

	masterConfig.whichPcs = EXAMPLE_DSPI_MASTER_PCS;
	masterConfig.pcsActiveHighOrLow = kDSPI_PcsActiveLow;

	masterConfig.enableContinuousSCK = false;
	masterConfig.enableRxFifoOverWrite = false;
	masterConfig.enableModifiedTimingFormat = false;
	masterConfig.samplePoint = kDSPI_SckToSin0Clock;

	srcClock_Hz = EXAMPLE_DSPI_MASTER_CLK_FREQ;
	DSPI_MasterInit(EXAMPLE_DSPI_MASTER_BASEADDR, &masterConfig, srcClock_Hz);

	isTransferCompleted = false;

	/* Enable the NVIC for DSPI peripheral. */
	EnableIRQ(EXAMPLE_DSPI_MASTER_IRQ);

	/* Start master transfer*/
	commandData.isPcsContinuous = false;
	commandData.whichCtar = kDSPI_Ctar0;
	commandData.whichPcs = EXAMPLE_DSPI_MASTER_PCS;
	commandData.isEndOfQueue = false;
	commandData.clearTransferCount = false;

	masterCommand = DSPI_MasterGetFormattedCommand(&commandData);

	masterFifoSize = FSL_FEATURE_DSPI_FIFO_SIZEn(EXAMPLE_DSPI_MASTER_BASEADDR);
	masterTxCount = 0;
	masterRxCount = 0;

	DSPI_StopTransfer(EXAMPLE_DSPI_MASTER_BASEADDR);
	DSPI_FlushFifo(EXAMPLE_DSPI_MASTER_BASEADDR, true, true);
	DSPI_ClearStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR, kDSPI_AllStatusFlag);
	DSPI_StartTransfer(EXAMPLE_DSPI_MASTER_BASEADDR);

	/*Fill up the master Tx data*/
	while (DSPI_GetStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR) & kDSPI_TxFifoFillRequestFlag)
	{
		if (masterTxCount < TRANSFER_SIZE)
		{
			DSPI_MasterWriteData(EXAMPLE_DSPI_MASTER_BASEADDR, &commandData, masterTxData[masterTxCount]);
			++masterTxCount;
		}
		else
		{
			break;
		}

		/* Try to clear the TFFF; if the TX FIFO is full this will clear */
		DSPI_ClearStatusFlags(EXAMPLE_DSPI_MASTER_BASEADDR, kDSPI_TxFifoFillRequestFlag);
	}

	/*Enable master RX interrupt*/
	DSPI_EnableInterrupts(EXAMPLE_DSPI_MASTER_BASEADDR, kDSPI_RxFifoDrainRequestInterruptEnable);
}

void pixyRead(){
	DSPI_MasterWriteData(EXAMPLE_DSPI_MASTER_BASEADDR, &commandData, masterTxData[masterTxCount]);
}

#endif /* SRC_PIXY_H_ */
