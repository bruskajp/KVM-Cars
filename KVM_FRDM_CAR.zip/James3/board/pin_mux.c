/*
 * TEXT BELOW IS USED AS SETTING FOR TOOLS *************************************
!!GlobalInfo
product: Pins v3.0
processor: MK64FN1M0xxx12
package_id: MK64FN1M0VLL12
mcu_data: ksdk2_0
processor_version: 2.0.0
board: FRDM-K64F
 * BE CAREFUL MODIFYING THIS COMMENT - IT IS YAML SETTINGS FOR TOOLS ***********
 */

#include "fsl_common.h"
#include "fsl_port.h"
#include "pin_mux.h"

/*FUNCTION**********************************************************************
 * 
 * Function Name : BOARD_InitBootPins
 * Description   : Calls initialization functions.
 * 
 *END**************************************************************************/
void BOARD_InitBootPins(void) {
    BOARD_InitPins();
}

#define PIN0_IDX                         0u   /*!< Pin number for pin 0 in a port */
#define PIN1_IDX                         1u   /*!< Pin number for pin 2 in a port */
#define PIN2_IDX                         2u   /*!< Pin number for pin 2 in a port */
#define PIN3_IDX                         3u   /*!< Pin number for pin 3 in a port */
#define PIN4_IDX                         4u   /*!< Pin number for pin 4 in a port */
#define PIN5_IDX                         5u   /*!< Pin number for pin 5 in a port */
#define PIN6_IDX                         6u   /*!< Pin number for pin 6 in a port */
#define PIN7_IDX                         7u   /*!< Pin number for pin 7 in a port */
#define PIN8_IDX                         8u   /*!< Pin number for pin 1 in a port */
#define PIN10_IDX                       10u   /*!< Pin number for pin 10 in a port */
#define PIN11_IDX                       11u   /*!< Pin number for pin 11 in a port */
#define PIN16_IDX                       16u   /*!< Pin number for pin 16 in a port */
#define PIN17_IDX                       17u   /*!< Pin number for pin 17 in a port */
#define PIN21_IDX                       21u   /*!< Pin number for pin 17 in a port */
#define PIN22_IDX                       22u   /*!< Pin number for pin 22 in a port */
#define PIN26_IDX                       26u   /*!< Pin number for pin 17 in a port */
#define SOPT5_UART0TXSRC_UART_TX      0x00u   /*!< UART 0 transmit data source select: UART0_TX pin */

/*
 * TEXT BELOW IS USED AS SETTING FOR TOOLS *************************************
BOARD_InitPins:
- options: {callFromInitBoot: 'true', coreID: core0, enableClock: 'true'}
- pin_list:
  - {pin_num: '62', peripheral: UART0, signal: RX, pin_signal: PTB16/SPI1_SOUT/UART0_RX/FTM_CLKIN0/FB_AD17/EWM_IN}
  - {pin_num: '63', peripheral: UART0, signal: TX, pin_signal: PTB17/SPI1_SIN/UART0_TX/FTM_CLKIN1/FB_AD16/EWM_OUT_b}
  - {pin_num: '82', peripheral: FTM3, signal: 'CH, 6', pin_signal: ADC1_SE6b/PTC10/I2C1_SCL/FTM3_CH6/I2S0_RX_FS/FB_AD5}
  - {pin_num: '83', peripheral: FTM3, signal: 'CH, 7', pin_signal: ADC1_SE7b/PTC11/LLWU_P11/I2C1_SDA/FTM3_CH7/I2S0_RXD1/FB_RW_b}
 * BE CAREFUL MODIFYING THIS COMMENT - IT IS YAML SETTINGS FOR TOOLS ***********
 */

/*FUNCTION**********************************************************************
 *
 * Function Name : BOARD_InitPins
 * Description   : Configures pin routing and optionally pin electrical features.
 *
 *END**************************************************************************/
void BOARD_InitPins(void) {
  CLOCK_EnableClock(kCLOCK_PortA);                           /* Port A Clock Gate Control: Clock enabled */
  CLOCK_EnableClock(kCLOCK_PortB);                           /* Port B Clock Gate Control: Clock enabled */
  CLOCK_EnableClock(kCLOCK_PortC);                           /* Port C Clock Gate Control: Clock enabled */
  CLOCK_EnableClock(kCLOCK_PortD);                           /* Port C Clock Gate Control: Clock enabled */
  CLOCK_EnableClock(kCLOCK_PortE);                           /* Port C Clock Gate Control: Clock enabled */

  const port_pin_config_t porta4_pin38_config = {
    kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
    kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
    kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
    kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
    kPORT_HighDriveStrength,                                 /* High drive strength is configured */
    kPORT_MuxAsGpio,                                         /* Pin is configured as PTA4 */
    kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
  };
  const port_pin_config_t portc6_pin78_config = {
      kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
      kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
      kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
      kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
      kPORT_HighDriveStrength,                                 /* High drive strength is configured */
      kPORT_MuxAsGpio,                                         /* Pin is configured as PTC6 */
      kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
  };
  PORT_SetPinConfig(PORTA, PIN4_IDX, &porta4_pin38_config);  /* PORTA4 (pin 38) is configured as PTA4 */
  PORT_SetPinConfig(PORTC, PIN6_IDX, &portc6_pin78_config);  /* PORTC6 (pin 78) is configured as PTC6 */
  PORT_SetPinMux(PORTC, PIN8_IDX, kPORT_MuxAlt3);            /* PORTC8 is configured as FTM3_CH4 */
  PORT_SetPinMux(PORTC, PIN10_IDX, kPORT_MuxAlt3);           /* PORTC10 (pin 82) is configured as FTM3_CH6 */
  PORT_SetPinMux(PORTC, PIN11_IDX, kPORT_MuxAlt3);           /* PORTC11 (pin 83) is configured as FTM3_CH7 */
  PORT_SetPinMux(PORTC, PIN2_IDX, kPORT_MuxAlt4);            /* PORTC2 (pin 72) is configured as FTM0_CH1 */
  PORT_SetPinMux(PORTB, PIN2_IDX, kPORT_PinDisabledOrAnalog); /* PORTB2 (pin 55) is configured as ADC0_SE12 */
  PORT_SetPinMux(PORTC, PIN1_IDX, kPORT_MuxAsGpio);          /* PORTC1 (pin 71) is configured as PTC1 */

  PORT_SetPinMux(PORTB, PIN16_IDX, kPORT_MuxAlt3);           /* PORTB16 (pin 62) is configured as UART0_RX */
  PORT_SetPinMux(PORTB, PIN17_IDX, kPORT_MuxAlt3);           /* PORTB17 (pin 63) is configured as UART0_TX */

  PORT_SetPinMux(PORTD, PIN0_IDX, kPORT_MuxAlt2);            /* PORTD0 (pin 93) is configured as SPI0_PCS0 */
  PORT_SetPinMux(PORTD, PIN1_IDX, kPORT_MuxAlt2);            /* PORTD1 (pin 94) is configured as SPI0_SCK */
  PORT_SetPinMux(PORTD, PIN2_IDX, kPORT_MuxAlt2);            /* PORTD2 (pin 95) is configured as SPI0_SOUT */
  PORT_SetPinMux(PORTD, PIN3_IDX, kPORT_MuxAlt2);            /* PORTD3 (pin 96) is configured as SPI0_SIN */

  PORT_SetPinMux(PORTB, PIN22_IDX, kPORT_MuxAsGpio);         /* PORTB22 (pin 68) is configured as PTB22 */
  PORT_SetPinMux(PORTB, PIN21_IDX, kPORT_MuxAsGpio);         /* PORTB21 (pin 68) is configured as PTB21 */
  PORT_SetPinMux(PORTE, PIN26_IDX, kPORT_MuxAsGpio);         /* PORTE26 (pin 68) is configured as PTE26 */


  const port_pin_config_t porte0_pin1_config = {
	  kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_HighDriveStrength,                                 /* High drive strength is configured */
	  kPORT_MuxAlt4,                                           /* Pin is configured as SDHC0_D1 */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN0_IDX, &porte0_pin1_config);   /* PORTE0 (pin 1) is configured as SDHC0_D1 */
	const port_pin_config_t porte1_pin2_config = {
	  kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_HighDriveStrength,                                 /* High drive strength is configured */
	  kPORT_MuxAlt4,                                           /* Pin is configured as SDHC0_D0 */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN1_IDX, &porte1_pin2_config);   /* PORTE1 (pin 2) is configured as SDHC0_D0 */
	const port_pin_config_t porte2_pin3_config = {
	  kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_HighDriveStrength,                                 /* High drive strength is configured */
	  kPORT_MuxAlt4,                                           /* Pin is configured as SDHC0_DCLK */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN2_IDX, &porte2_pin3_config);   /* PORTE2 (pin 3) is configured as SDHC0_DCLK */
	const port_pin_config_t porte3_pin4_config = {
	  kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_HighDriveStrength,                                 /* High drive strength is configured */
	  kPORT_MuxAlt4,                                           /* Pin is configured as SDHC0_CMD */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN3_IDX, &porte3_pin4_config);   /* PORTE3 (pin 4) is configured as SDHC0_CMD */
	const port_pin_config_t porte4_pin5_config = {
	  kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_HighDriveStrength,                                 /* High drive strength is configured */
	  kPORT_MuxAlt4,                                           /* Pin is configured as SDHC0_D3 */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN4_IDX, &porte4_pin5_config);   /* PORTE4 (pin 5) is configured as SDHC0_D3 */
	const port_pin_config_t porte5_pin6_config = {
	  kPORT_PullUp,                                            /* Internal pull-up resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_HighDriveStrength,                                 /* High drive strength is configured */
	  kPORT_MuxAlt4,                                           /* Pin is configured as SDHC0_D2 */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN5_IDX, &porte5_pin6_config);   /* PORTE5 (pin 6) is configured as SDHC0_D2 */
	const port_pin_config_t porte6_pin7_config = {
	  kPORT_PullDown,                                          /* Internal pull-down resistor is enabled */
	  kPORT_FastSlewRate,                                      /* Fast slew rate is configured */
	  kPORT_PassiveFilterDisable,                              /* Passive filter is disabled */
	  kPORT_OpenDrainDisable,                                  /* Open drain is disabled */
	  kPORT_LowDriveStrength,                                  /* Low drive strength is configured */
	  kPORT_MuxAsGpio,                                         /* Pin is configured as PTE6 */
	  kPORT_UnlockRegister                                     /* Pin Control Register fields [15:0] are not locked */
	};
	PORT_SetPinConfig(PORTE, PIN6_IDX, &porte6_pin7_config);   /* PORTE6 (pin 7) is configured as PTE6 */

  SIM->SOPT5 = ((SIM->SOPT5 &
    (~(SIM_SOPT5_UART0TXSRC_MASK)))                          /* Mask bits to zero which are setting */
      | SIM_SOPT5_UART0TXSRC(SOPT5_UART0TXSRC_UART_TX)       /* UART 0 transmit data source select: UART0_TX pin */
    );
}

/*******************************************************************************
 * EOF
 ******************************************************************************/
